
public class RecaptchaConstants {
    public static final String SECRET_KEY ="6Ld_CuYlAAAAAOSMhAsFyzh214Y3ZbZP-Agkh9GF";

}
